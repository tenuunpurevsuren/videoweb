// client.js
const localVideo = document.getElementById('localVideo');
const remoteVideo = document.getElementById('remoteVideo');
const joinBtn = document.getElementById('joinBtn');
const leaveBtn = document.getElementById('leaveBtn');
const startCamBtn = document.getElementById('startCamBtn');
const shareScreenBtn = document.getElementById('shareScreenBtn');
const hangupBtn = document.getElementById('hangupBtn');
const toggleMicBtn = document.getElementById('toggleMicBtn');
const toggleCamBtn = document.getElementById('toggleCamBtn');
const statusEl = document.getElementById('status');
const roomInput = document.getElementById('roomId');

let localStream = null;
let pc = null;
let ws = null;
let roomId = null;
let isInitiator = false;
let audioEnabled = true;
let videoEnabled = true;

const ICE_CONFIG = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' }
  ]
};

function logStatus(t) { statusEl.textContent = t; console.log(t); }

function connectWebSocket() {
  const loc = window.location;
  const wsProtocol = (loc.protocol === 'https:') ? 'wss:' : 'ws:';
  const wsUrl = `${wsProtocol}//${loc.host}`;
  ws = new WebSocket(wsUrl);

  ws.addEventListener('open', () => {
    logStatus('Signalling connected. Joining room...');
    ws.send(JSON.stringify({ type: 'join', roomId }));
  });

  ws.addEventListener('message', async (ev) => {
    const data = JSON.parse(ev.data);
    const { type, payload } = data;

    if (type === 'joined') {
      // payload.clients tells how many in room including us
      const clients = payload.clients || 1;
      isInitiator = clients === 2 ? false : true; // if we are first, we'll be initiator (offerer) when second joins
      logStatus(`Joined room "${roomId}". Clients in room: ${clients}. You ${isInitiator ? 'wait for peer' : 'are the callee'}.`);
      startCamBtn.disabled = false;
      shareScreenBtn.disabled = false;
      toggleMicBtn.disabled = false;
      toggleCamBtn.disabled = false;
      hangupBtn.disabled = false;
      leaveBtn.disabled = false;
      joinBtn.disabled = true;
      roomInput.disabled = true;
      // If there are 2 clients and we are not the one who started last, create offer? The first who joined should create offer when second arrives.
      if (clients === 2 && isInitiator) {
        // Wait a little for local tracks
        maybeCreateOffer();
      }
      return;
    }

    if (type === 'offer') {
      logStatus('Received offer');
      await ensurePc();
      await pc.setRemoteDescription(new RTCSessionDescription(payload));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      ws.send(JSON.stringify({ type: 'answer', payload: pc.localDescription }));
      return;
    }

    if (type === 'answer') {
      logStatus('Received answer');
      await pc.setRemoteDescription(new RTCSessionDescription(payload));
      return;
    }

    if (type === 'candidate') {
      // add candidate
      try {
        await pc.addIceCandidate(new RTCIceCandidate(payload));
      } catch (e) {
        console.warn('Error adding received ICE candidate', e);
      }
      return;
    }

    if (type === 'peer-left') {
      logStatus('Peer left the room.');
      cleanupPeer();
      return;
    }
  });

  ws.addEventListener('close', () => {
    logStatus('Signalling disconnected');
  });
}

async function ensurePc() {
  if (pc) return;
  pc = new RTCPeerConnection(ICE_CONFIG);

  pc.onicecandidate = (e) => {
    if (e.candidate && ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'candidate', payload: e.candidate }));
    }
  };

  pc.ontrack = (e) => {
    // attach remote stream
    remoteVideo.srcObject = e.streams[0];
  };

  // if local stream exists, add tracks
  if (localStream) {
    localStream.getTracks().forEach(track => {
      pc.addTrack(track, localStream);
    });
  }
}

async function maybeCreateOffer() {
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    console.warn('WebSocket not open yet');
    return;
  }
  await ensurePc();
  // Only create offer if we are the first/initiator
  if (!isInitiator) return;
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  ws.send(JSON.stringify({ type: 'offer', payload: pc.localDescription }));
  logStatus('Sent offer');
}

async function startCamera() {
  try {
    if (!localStream) {
      localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      localVideo.srcObject = localStream;
      // add tracks to pc if exists
      if (pc) {
        localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
      }
    }
    logStatus('Camera started');
  } catch (e) {
    console.error('getUserMedia error', e);
    alert('Could not start camera/mic: ' + e.message);
  }
}

async function shareScreen() {
  try {
    const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
    // replace video tracks in pc
    const screenTrack = screenStream.getVideoTracks()[0];
    // add the screen track to localVideo preview (combine with audio)
    // If there is an existing localStream we may want to keep audio tracks
    const outgoingStream = new MediaStream();
    // keep audio tracks from localStream if available
    if (localStream) {
      localStream.getAudioTracks().forEach(t => outgoingStream.addTrack(t));
    } else {
      // try to get audio from mic so the screen share has audio
      try {
        const mic = await navigator.mediaDevices.getUserMedia({ audio: true });
        mic.getAudioTracks().forEach(t => outgoingStream.addTrack(t));
      } catch (e) { console.warn('no mic for screenshare audio', e); }
    }
    outgoingStream.addTrack(screenTrack);
    localVideo.srcObject = outgoingStream;

    // If a pc exists, replace the video sender's track
    if (pc) {
      const senders = pc.getSenders();
      // try to find a video sender to replace
      const videoSender = senders.find(s => s.track && s.track.kind === 'video');
      if (videoSender) {
        await videoSender.replaceTrack(screenTrack);
      } else {
        // if there's no sender, add the track
        pc.addTrack(screenTrack, outgoingStream);
      }
    } else {
      // if no peer connection yet, set localStream so future pc will add tracks
      localStream = outgoingStream;
    }

    // when screen sharing stops, revert to camera
    screenTrack.onended = async () => {
      logStatus('Screen share stopped; reverting to camera (if available)');
      // revert to camera track if we have it
      if (localStream && localStream.getVideoTracks().length === 0 && navigator.mediaDevices) {
        try {
          const cam = await navigator.mediaDevices.getUserMedia({ video: true });
          const camTrack = cam.getVideoTracks()[0];
          // attach to localStream
          localStream.addTrack(camTrack);
          localVideo.srcObject = localStream;
          if (pc) {
            const senders = pc.getSenders();
            const videoSender = senders.find(s => s.track && s.track.kind === 'video');
            if (videoSender) {
              await videoSender.replaceTrack(camTrack);
            } else {
              pc.addTrack(camTrack, localStream);
            }
          }
        } catch (e) {
          console.warn('Could not restore camera after screenshare', e);
        }
      }
    };

    logStatus('Sharing screen');
  } catch (e) {
    console.error('getDisplayMedia error', e);
    alert('Could not share screen: ' + e.message);
  }
}

function toggleTrack(kind) {
  if (!localStream) return;
  if (kind === 'audio') {
    audioEnabled = !audioEnabled;
    localStream.getAudioTracks().forEach(t => t.enabled = audioEnabled);
    toggleMicBtn.textContent = audioEnabled ? 'Mute Mic' : 'Unmute Mic';
  } else if (kind === 'video') {
    videoEnabled = !videoEnabled;
    localStream.getVideoTracks().forEach(t => t.enabled = videoEnabled);
    toggleCamBtn.textContent = videoEnabled ? 'Stop Cam' : 'Start Cam';
  }
}

function cleanupPeer() {
  if (pc) {
    try { pc.close(); } catch(e) {}
    pc = null;
  }
  remoteVideo.srcObject = null;
  // keep local stream so user can re-offer
}

function hangup() {
  // tell other peer? We simply close local pc and keep ws
  cleanupPeer();
  logStatus('Call ended locally');
}

function leaveRoom() {
  if (ws && ws.readyState === WebSocket.OPEN) {
    try { ws.close(); } catch(e) {}
  }
  cleanupPeer();
  if (localStream) {
    localStream.getTracks().forEach(t => t.stop());
    localStream = null;
    localVideo.srcObject = null;
  }
  remoteVideo.srcObject = null;
  joinBtn.disabled = false;
  roomInput.disabled = false;
  leaveBtn.disabled = true;
  startCamBtn.disabled = true;
  shareScreenBtn.disabled = true;
  hangupBtn.disabled = true;
  toggleMicBtn.disabled = true;
  toggleCamBtn.disabled = true;
  logStatus('Left room');
}

joinBtn.addEventListener('click', () => {
  roomId = roomInput.value.trim();
  if (!roomId) return alert('Type a room id');
  connectWebSocket();
});

leaveBtn.addEventListener('click', () => {
  leaveRoom();
});

startCamBtn.addEventListener('click', async () => {
  await startCamera();
  // if already joined, ensure pc and add tracks
  await ensurePc();
  // if we are initiator and peer exists, create an offer
  // let maybeCreateOffer handle offer timing (it will not create if not initiator)
  if (isInitiator) {
    maybeCreateOffer();
  }
});

shareScreenBtn.addEventListener('click', shareScreen);
hangupBtn.addEventListener('click', hangup);
toggleMicBtn.addEventListener('click', () => toggleTrack('audio'));
toggleCamBtn.addEventListener('click', () => toggleTrack('video'));

// before unload
window.addEventListener('beforeunload', () => {
  if (ws && ws.readyState === WebSocket.OPEN) ws.close();
});