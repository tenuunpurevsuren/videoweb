// server.js
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static(path.join(__dirname, 'public')));

// rooms: map roomId -> Set of ws
const rooms = new Map();

wss.on('connection', (ws) => {
  ws.roomId = null;
  ws.on('message', (msg) => {
    let data;
    try { data = JSON.parse(msg); } catch (e) { console.warn('Invalid JSON', e); return; }
    const { type, roomId, payload } = data;

    if (type === 'join') {
      ws.roomId = roomId;
      if (!rooms.has(roomId)) rooms.set(roomId, new Set());
      rooms.get(roomId).add(ws);
      // notify how many clients
      const clients = rooms.get(roomId).size;
      // send back a confirmation
      ws.send(JSON.stringify({ type: 'joined', payload: { clients } }));
      return;
    }

    // Forward signalling messages to others in same room
    const set = rooms.get(ws.roomId || roomId);
    if (!set) return;
    set.forEach(client => {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({ type, payload }));
      }
    });
  });

  ws.on('close', () => {
    const r = ws.roomId;
    if (!r) return;
    const set = rooms.get(r);
    if (!set) return;
    set.delete(ws);
    if (set.size === 0) rooms.delete(r);
    else {
      // notify remaining peer that someone left
      set.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({ type: 'peer-left' }));
        }
      });
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));